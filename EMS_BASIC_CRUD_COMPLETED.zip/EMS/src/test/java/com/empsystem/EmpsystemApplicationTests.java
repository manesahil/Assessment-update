package com.empsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
