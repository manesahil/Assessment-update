package com.empsystem.service;

import java.util.List;

import com.empsystem.model.Project;

public interface ProjectService {

	public void add(Project project);

	public void deletebyid(Long id);

	public List<Project> viewall();

	public Project viewbyid(Long id);

	public void update(Long id, Project project);

}
