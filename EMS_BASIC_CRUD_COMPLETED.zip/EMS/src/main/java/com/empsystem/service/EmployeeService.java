package com.empsystem.service;

import java.util.List;

import com.empsystem.dto.EmployeeRequest;
import com.empsystem.model.Employee;

public interface EmployeeService {
	public void insertemp(EmployeeRequest EmployeeRequest);

	public EmployeeRequest viewbyid(Long id);

	public List<EmployeeRequest> viewall();

	public void Deletebyid(Long id);

	public void UpdateDeptno(Long id, Long departmentId);

	public List<EmployeeRequest> findSorted(String sortBy);

	public List<EmployeeRequest> findPaginated(int page, int size);
	
	public List<EmployeeRequest> sortbydept(Long departmentId);
}
