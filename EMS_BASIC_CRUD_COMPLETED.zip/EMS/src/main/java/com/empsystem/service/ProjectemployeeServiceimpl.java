package com.empsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empsystem.model.employeeprojects;
import com.empsystem.repository.projectemployeerepository;

@Service
public class ProjectemployeeServiceimpl implements ProjectemployeeService {

	@Autowired
	private projectemployeerepository Projectemployeerepository;

	@Override
	public void add(employeeprojects Employeeprojects) {
		Projectemployeerepository.add(Employeeprojects);
	}

	@Override
	public List<employeeprojects> Viewbyid(Long id) {
		return Projectemployeerepository.Viewbyid(id);
	}

	@Override
	public void deleteById(Long employeeId, Long projectId) {
		Projectemployeerepository.deleteById(employeeId,projectId);
	}

	@Override
	public List<employeeprojects> viewall() {
		return Projectemployeerepository.viewall();
	}

}
