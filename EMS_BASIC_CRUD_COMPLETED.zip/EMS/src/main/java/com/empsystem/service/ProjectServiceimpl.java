package com.empsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empsystem.model.Project;
import com.empsystem.repository.Projectrepository;

@Service
public class ProjectServiceimpl implements ProjectService {
	@Autowired
	private Projectrepository projectrepository;

	public void add(Project project) {
		projectrepository.add(project);
	}

	@Override
	public void deletebyid(Long id) {
		projectrepository.deletebyid(id);
	}

	@Override
	public List<Project> viewall() {
		return projectrepository.viewall();

	}

	@Override
	public Project viewbyid(Long id) {
		return projectrepository.viewbyid(id);
	}

	@Override
	public void update(Long id, Project project) {
		projectrepository.update(id, project);
	}

}
