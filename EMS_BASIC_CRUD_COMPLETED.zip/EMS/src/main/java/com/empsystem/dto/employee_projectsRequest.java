package com.empsystem.dto;

public class employee_projectsRequest {

	private Long employee_id;
	private Long project_id;

	public employee_projectsRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public employee_projectsRequest(Long employee_id, Long project_id) {
		super();
		this.employee_id = employee_id;
		this.project_id = project_id;
	}

	public Long getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(Long employee_id) {
		this.employee_id = employee_id;
	}

	public Long getProject_id() {
		return project_id;
	}

	public void setProject_id(Long project_id) {
		this.project_id = project_id;
	}

}
