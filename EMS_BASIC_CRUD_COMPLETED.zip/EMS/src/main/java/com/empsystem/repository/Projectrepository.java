package com.empsystem.repository;

import java.util.List;

import com.empsystem.model.Project;

public interface Projectrepository {

	public void add(Project project);

	public void deletebyid(Long id);

	public List<Project> viewall();

	public Project viewbyid(Long id);

	public void update(Long id, Project project);

}
