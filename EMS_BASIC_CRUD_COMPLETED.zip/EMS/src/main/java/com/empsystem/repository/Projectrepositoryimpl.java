package com.empsystem.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.empsystem.model.Project;
import com.empsystem.model.ProjectRowMapper;

@Repository
public class Projectrepositoryimpl implements Projectrepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void add(Project project) {
		String sql = "INSERT INTO projects (name,description)VALUES(?,?)";
		jdbcTemplate.update(sql, project.getName(), project.getDesciption());
	}

	public void deletebyid(Long id) {

		String sql = "DELETE FROM projects WHERE id=?";
		jdbcTemplate.update(sql, id);
	}

	public List<Project> viewall() {
		String sql = "SELECT * FROM projects";
		return jdbcTemplate.query(sql, new ProjectRowMapper());
	}

	public Project viewbyid(Long id) {
		String sql = "SELECT * FROM projects WHERE id = ?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new ProjectRowMapper());
	}

	public void update(Long id, Project project) {
		String sql = "UPDATE projects SET name=? , description=? WHERE id=?";
		jdbcTemplate.update(sql, project.getName(), project.getDesciption(), id);
	}

}
