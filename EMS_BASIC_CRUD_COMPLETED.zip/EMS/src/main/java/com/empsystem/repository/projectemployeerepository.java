package com.empsystem.repository;

import java.util.List;

import com.empsystem.model.employeeprojects;

public interface projectemployeerepository {

	public void add(employeeprojects Employeeprojects);

	public List<employeeprojects> Viewbyid(Long id);

	public void deleteById(Long employeeId, Long projectId);
	
	public List<employeeprojects> viewall();
}
