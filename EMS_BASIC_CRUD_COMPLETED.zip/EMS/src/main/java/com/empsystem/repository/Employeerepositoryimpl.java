package com.empsystem.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.empsystem.dto.EmployeeRequest;
import com.empsystem.model.Employee;
import com.empsystem.model.EmployeeRowMapper;

@Repository
public class Employeerepositoryimpl implements Employeerepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void insertemp(EmployeeRequest EmployeeRequest) {
		String sql = "INSERT INTO employees(first_name, last_name, email, department_id) VALUES(?,?,?,?)";
		jdbcTemplate.update(sql, EmployeeRequest.getFirstName(), EmployeeRequest.getLastName(),
				EmployeeRequest.getEmail(), EmployeeRequest.getDepartmentId());

	}

	public EmployeeRequest viewbyid(Long id) {
		String sql = "SELECT * FROM employees WHERE id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new EmployeeRowMapper());
	}

	public List<EmployeeRequest> viewall() {
		String sql = "SELECT * FROM employees";
		return jdbcTemplate.query(sql, new EmployeeRowMapper());

	}

	public void Deletebyid(Long id) {
		String sql = "DELETE FROM employees WHERE id=? ";
		jdbcTemplate.update(sql, id);
	}

	public void UpdateDeptno(Long id, Long departmentId) {
		String sql = "UPDATE employees SET department_id=? WHERE id=?";
		jdbcTemplate.update(sql, departmentId, id);
	}

	public List<EmployeeRequest> findSorted(String sortBy) {
		String sql = "SELECT * FROM employees ORDER BY " + sortBy;
		return jdbcTemplate.query(sql, new EmployeeRowMapper());
	}

	@SuppressWarnings("deprecation")
	public List<EmployeeRequest> findPaginated(int page, int size) {
		int offset = (page - 1) * size;
		String sql = "SELECT * FROM employees LIMIT ? OFFSET ?";
		return jdbcTemplate.query(sql, new Object[] { size, offset }, new EmployeeRowMapper());
	}

	 @SuppressWarnings("deprecation")
	public List<EmployeeRequest> sortbydept(Long departmentId) {
		String sql="SELECT * FROM employees WHERE department_id=?";
		return jdbcTemplate.query(sql,new Object[] {departmentId},new EmployeeRowMapper());
		
	}

}
