package com.empsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.empsystem.model.Department;
import com.empsystem.service.DepartmentService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	private DepartmentService DepartmentService;

	@PostMapping("/add")
	public ResponseEntity<String> deptadd(@RequestBody Department department) {
		DepartmentService.deptadd(department);

		return ResponseEntity.ok("Department data added ");
	}

	@PostMapping("/viewbyid/{id}")
	public ResponseEntity<Department> Viewbyid(@PathVariable Long id) {
		DepartmentService.Viewbyid(id);
		return ResponseEntity.ok(DepartmentService.Viewbyid(id));

	}

	@PostMapping("/deletebyid/{id}")
	public ResponseEntity<String> deletebyid(@PathVariable Long id) {
		DepartmentService.deletebyid(id);

		return ResponseEntity.ok("Data Deleted");
	}

	@PostMapping("/viewall")
	public ResponseEntity<List<Department>> viewall() {
		DepartmentService.viewall();

		return ResponseEntity.ok(DepartmentService.viewall());
	}

	@PostMapping("/update")
	public ResponseEntity<String> update(@RequestBody Department department) {
		Long id = department.getId();
		if (id == null) {
			return ResponseEntity.badRequest().body("ID is required for update");
		}

		DepartmentService.update(id, department);

		return ResponseEntity.ok("Update done!!");
	}

}
