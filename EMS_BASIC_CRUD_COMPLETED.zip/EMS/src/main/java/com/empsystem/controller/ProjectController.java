package com.empsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.empsystem.model.Project;
import com.empsystem.service.ProjectService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/project")
public class ProjectController {

	@Autowired
	private ProjectService projectService;

	@PostMapping("/add")
	public ResponseEntity<String> add(@RequestBody Project project) {
		projectService.add(project);

		return ResponseEntity.ok("Data added");
	}
	
	@PostMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable Long id) {
		projectService.deletebyid(id);
		return ResponseEntity.ok("Data Deleted");
	}
	
	@PostMapping("/viewall")
	public ResponseEntity<List<Project>> viewall() {
		projectService.viewall();
		
		return ResponseEntity.ok(projectService.viewall());
	}
	
	@PostMapping("/viewbyid/{id}")
	public ResponseEntity<Project> viewbyid(@PathVariable Long id) {
		projectService.viewbyid(id);
		
		return ResponseEntity.ok(projectService.viewbyid(id));
	}
	
	@PostMapping("/update")
	public ResponseEntity<String> update(@RequestBody Project project) {
		Long id = project.getId();
		projectService.update(id, project);
		
		return ResponseEntity.ok("Data updated");
	}
	
	

}
