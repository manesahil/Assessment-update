package com.empsystem.repository;

public interface projectemployeerepository  {

}
