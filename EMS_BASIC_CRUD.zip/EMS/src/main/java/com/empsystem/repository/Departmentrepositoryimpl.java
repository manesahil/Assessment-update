package com.empsystem.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.empsystem.model.Department;
import com.empsystem.model.DepartmentRowMapper;

@Repository
public class Departmentrepositoryimpl implements Departmentrepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void deptadd(Department department) {
		String sql = "INSERT INTO departments (name,description)VALUES(?,?)";
		jdbcTemplate.update(sql, department.getName(), department.getDesciption());
	}

	public Department Viewbyid(Long id) {
		String sql = "SELECT * FROM departments WHERE department_id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new DepartmentRowMapper());
	}
}
