package com.empsystem.repository;

import com.empsystem.model.Department;

public interface Departmentrepository {

	public void deptadd(Department department);

	public Department Viewbyid(Long id);

}
