package com.empsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empsystem.model.Department;
import com.empsystem.repository.Departmentrepository;

@Service
public class DepartmentServiceimpl implements DepartmentService {

	@Autowired
	private Departmentrepository departmentrepository;

	@Override
	public void deptadd(Department department) {
		departmentrepository.deptadd(department);
	}

	@Override
	public Department Viewbyid(Long id) {
		return departmentrepository.Viewbyid(id);

	}

}
