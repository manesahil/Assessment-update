package com.empsystem.service;

import com.empsystem.model.Department;

public interface DepartmentService {
	

	public void deptadd(Department department);
	
	public Department Viewbyid(Long id) ;
}
