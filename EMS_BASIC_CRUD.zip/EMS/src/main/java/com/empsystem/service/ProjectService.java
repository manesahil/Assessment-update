package com.empsystem.service;

public interface ProjectService {

}
