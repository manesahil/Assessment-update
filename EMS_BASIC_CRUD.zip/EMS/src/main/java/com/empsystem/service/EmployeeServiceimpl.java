package com.empsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empsystem.dto.EmployeeRequest;
import com.empsystem.model.Employee;
import com.empsystem.repository.Employeerepository;

@Service
public class EmployeeServiceimpl implements EmployeeService {

	@Autowired
	private Employeerepository employeerepository;

	@Override
	public void insertemp(EmployeeRequest EmployeeRequest) {
		employeerepository.insertemp(EmployeeRequest);

	}

	@Override
	public EmployeeRequest viewbyid(Long id) {

		return employeerepository.viewbyid(id);
	}

	@Override
	public List<EmployeeRequest> viewall() {
		
		return employeerepository.viewall();
	}

	@Override
	public void Deletebyid(Long id) {
		employeerepository.Deletebyid(id);
		
	}

	@Override
	public void UpdateDeptno(Long id, Long departmentId) {
		employeerepository.UpdateDeptno(departmentId, id);
		
	}

}
