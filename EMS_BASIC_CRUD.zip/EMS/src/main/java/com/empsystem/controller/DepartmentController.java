package com.empsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empsystem.model.Department;
import com.empsystem.service.DepartmentService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	private DepartmentService DepartmentService;

	@PostMapping("/add")
	public ResponseEntity<String> deptadd(@RequestBody Department department) {
		DepartmentService.deptadd(department);

		return ResponseEntity.ok("Department data added ");
	}

	@PostMapping("/viewbyid/{id}")
	public ResponseEntity<Department> Viewbyid(@PathVariable Long id) {
		DepartmentService.Viewbyid(id);
		return ResponseEntity.ok(DepartmentService.Viewbyid(id));

	}

}
