package com.empsystem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.empsystem.dto.EmployeeRequest;

public class EmployeeRowMapper implements RowMapper<EmployeeRequest> {

	@Override
	public EmployeeRequest mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmployeeRequest EmployeeRequest = new EmployeeRequest();
		EmployeeRequest.setId(rs.getLong("id"));
		EmployeeRequest.setFirstName(rs.getString("first_name"));
		EmployeeRequest.setLastName(rs.getString("last_name"));
		EmployeeRequest.setEmail(rs.getString("email"));
//		Department department = new Department();
//		department.setId(rs.getLong("departmentid"));
		EmployeeRequest.setDepartmentId(rs.getLong("department_id"));
		return EmployeeRequest;
	}

}
