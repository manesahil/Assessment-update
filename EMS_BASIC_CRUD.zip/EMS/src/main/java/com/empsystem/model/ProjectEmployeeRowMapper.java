package com.empsystem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProjectEmployeeRowMapper implements RowMapper<Project> {

	@Override
	public Project mapRow(ResultSet rs, int rowNum) throws SQLException {
		Project project = new Project();
		project.setId(rs.getLong("id"));
		project.setName(rs.getString("name"));
		project.setDesciption(rs.getString("Desciption"));
		
		return project;
	}

}
